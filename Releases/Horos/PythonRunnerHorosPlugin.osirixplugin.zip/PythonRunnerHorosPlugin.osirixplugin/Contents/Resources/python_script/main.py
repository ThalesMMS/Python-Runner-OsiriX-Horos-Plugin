# 
# main.py
# PythonRunner
#
# Python script to be run by the Horos plugin
#
# Thales Matheus Mendonca Santos - January 2026
# 

def main():
    # Keep output immediate so it shows up in the Xcode console.
    print("Hello world!!", flush=True)


if __name__ == "__main__":
    # Explicit entrypoint for direct execution.
    main()
